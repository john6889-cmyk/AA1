package com.wsn.digitalsandtable.entity;

import lombok.Data;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/23 15:59
 * @Version 1.0
 */
@Data
public class Status {
    private String vendor;
    private String name;
    private String property;
    private Integer resId;
    private Integer id;
    private String time;
}
