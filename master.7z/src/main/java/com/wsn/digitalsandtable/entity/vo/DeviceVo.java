package com.wsn.digitalsandtable.entity.vo;

import lombok.Data;

/**
 * @author liwu
 * @date 2022.1.11 18:38
 */
@Data
public class DeviceVo {
    private Integer resId;
    private String name;
    private String vendor;
    private String chName;
    private String district;
    private String campsite;
}
