package com.wsn.digitalsandtable.entity.param;

import lombok.Data;

import java.util.List;

/**
 * @author liwu
 * @date 2022.1.11 20:34
 */
@Data
public class DeviceMoveParam {
    private List<Integer> resIdList;
    private String campsite;
}
