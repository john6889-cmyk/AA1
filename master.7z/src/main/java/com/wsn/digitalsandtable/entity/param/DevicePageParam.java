package com.wsn.digitalsandtable.entity.param;

import lombok.Data;

/**
 * @author liwu
 * @date 2022.1.11 18:44
 */
@Data
public class DevicePageParam {
    private Integer pageNum = 1;
    private Integer pageSize = 10;
    /**
     * 设备大类
     */
    private String chName;
    /**
     * 所在位置
     */
    private String district;
    /**
     * 所在营区
     */
    private String campsite;
}
