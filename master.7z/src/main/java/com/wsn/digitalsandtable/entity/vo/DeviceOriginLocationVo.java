package com.wsn.digitalsandtable.entity.vo;

import lombok.Data;

/**
 * @author liwu
 * @date 2022.1.11 20:05
 */
@Data
public class DeviceOriginLocationVo {
    private Integer resId;
    private String originDistrict;
    private String originCampsite;
}
