package com.wsn.digitalsandtable.entity;

import lombok.Data;

/**
 * @Author ZhaoMingHui
 * @Date 2021/10/13 15:50
 * @Version 1.0
 */
@Data
public class LogisOrder {

    private Integer id;
    private String deliveryTime;
    private String orderStatus;
    private String senderAddress;
    private String senderName;
    private String senderPhone;
    private String userAddress;
    private String userId;
    private String userName;
    private String userPhone;
    private String qrCode;
}
