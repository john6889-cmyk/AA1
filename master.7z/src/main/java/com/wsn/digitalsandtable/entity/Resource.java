package com.wsn.digitalsandtable.entity;

import lombok.Data;

import java.util.concurrent.CountDownLatch;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/16 10:11
 * @Version 1.0
 *
 * 数据库静态资源实体类
 */
@Data
public class Resource implements Comparable{
    private Integer resId;
    private String vendor;
    private String name;
    private String district;
    private String lon;
    private String lat;
    private String property;
    private String ip;
    private String campsite;
    private String chName;
    private String originDistrict;
    private String originCampsite;

    @Override
    public int compareTo(Object o) {
        if (this.getName().compareTo(((Resource)o).getName()) > 0){
            return 1;
        }else if (this.getName().compareTo(((Resource)o).getName()) < 0){
            return -1;
        }else {
            return this.getResId() - ((Resource)o).getResId();
        }
    }

    public String getChName() {
        return chName;
    }


    public void setName(String name) {
        this.name = name;
    }
}
