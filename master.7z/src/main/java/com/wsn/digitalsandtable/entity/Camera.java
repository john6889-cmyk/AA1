package com.wsn.digitalsandtable.entity;

import lombok.Data;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/18 10:12
 * @Version 1.0
 */

@Data
public class Camera {

    private Integer resId;
    private String deviceType;
    private String brand;
    private String model;
    private String url;
    private String district;
    private String campsite;
    private String ip;
    private String lon;
    private String lat;
}
