package com.wsn.digitalsandtable.request;

import lombok.Data;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/29 10:18
 * @Version 1.0
 */
@Data
public class ControlRequest {
    private Integer resId;
    private String command;
}
