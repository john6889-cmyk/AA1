package com.wsn.digitalsandtable.request;

import lombok.Data;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/18 11:23
 * @Version 1.0
 * 请求对象
 */
@Data       //RO
public class DeviceListRequest {

    private String campName;
    private String buildingName;
    private Integer resId;
}
