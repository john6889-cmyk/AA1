package com.wsn.digitalsandtable.mapper;

import com.wsn.digitalsandtable.entity.Camera;
import com.wsn.digitalsandtable.entity.LogisOrder;
import com.wsn.digitalsandtable.entity.Resource;
import com.wsn.digitalsandtable.entity.Status;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ResourceMapper {

    List<Resource> queryResourceListByCamOrDis(String campName, String buildingName);

    List<Camera> queryCameraListByCamOrDis(String campName, String buildingName);

    Integer insertDeviceState(String vendor, String name, String property, Integer resId);

    Integer updateDeviceStatus(Integer id, String vendor, String name, String property, Integer resId);

    List<Integer> queryResIdByCampAndBuilding(String campName, String buildingName);

    Status queryStatusByResId(Integer resId);

    String queryIpByResId(Integer resId);

    Resource queryValveByName(String name);

    List<Resource> queryMotionResourceByVendorAndName(String vendor, String name);

    List<Resource> queryResourceByNameAndDistrictAndCampsite(String name, String district, String campsite);

    Resource queryConferenceTerminalByVendor(String vendor);

    List<Resource> queryResourceByChName(String chName);

    Resource queryConferenceTerminalByVendorAndIp(String vendor, String ip);

    Resource queryResourceByResId(Integer resId);

    List<Status> queryLow15Limit(Integer resId);

    Integer insertLogisOrderData(Integer id, String deliveryTime, String orderStatus, String senderAddress, String senderName, String senderPhone, String userAddress, String userId, String userName, String userPhone, String qrCode);

    List<String> queryAllOrderDistinct();

    LogisOrder queryOrderDetailById(String id);

    List<String> queryAllCampDistinct();

    List<String> queryDistrictByCampname(String campName);

    Status getResourceStateById(@Param("resId") Integer resId);

    List<Resource> getStates();

    Status queryStatusBysid(@Param("sid") String sid);
}
