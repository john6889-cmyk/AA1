package com.wsn.digitalsandtable.mapper;

import com.wsn.digitalsandtable.entity.param.DevicePageParam;
import com.wsn.digitalsandtable.entity.vo.DeviceOriginLocationVo;
import com.wsn.digitalsandtable.entity.vo.DeviceVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liwu
 * @date 2022.1.11 19:03
 */
public interface DeviceMapper {
    List<DeviceVo> selectPageVo(@Param("param") DevicePageParam param);

    List<DeviceOriginLocationVo> getAllDeviceLocation();

    void updateDeviceLocation(@Param("resId") Integer resId,
                              @Param("campsite") String originCampsite,
                              @Param("district") String originDistrict);


    void updateDeviceCampsite(@Param("resId") Integer resId, @Param("campsite") String campsite);

    int selectLastPlugId();

    String selectLastPlugProperty(@Param("id") int id);
    String selectLastPlug();
}
