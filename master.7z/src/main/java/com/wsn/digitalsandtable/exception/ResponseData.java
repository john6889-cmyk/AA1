package com.wsn.digitalsandtable.exception;

public class ResponseData {

    private Integer code;
    private String message;
    private String urL;
    private boolean status;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUrL() {
        return urL;
    }

    public void setUrL(String urL) {
        this.urL = urL;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}
