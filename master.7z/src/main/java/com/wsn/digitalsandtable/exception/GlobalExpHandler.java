package com.wsn.digitalsandtable.exception;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletRequest;

@ControllerAdvice
@CrossOrigin
public class GlobalExpHandler extends Exception{

    private Logger logger = LoggerFactory.getLogger(GlobalExpHandler.class);

    @ExceptionHandler(value = Exception.class)
    @ResponseBody
    public ResponseData defaultErrorHandler(HttpServletRequest request, Exception e) throws Exception{
        logger.error("",e);
        ResponseData responseData = new ResponseData();
        responseData.setMessage(e.getMessage());
        if(e instanceof NoHandlerFoundException){
            responseData.setCode(404);
            responseData.setMessage("no such interface！");
        }else {
            responseData.setCode(500);
            responseData.setMessage("internal server error！");
        }
        responseData.setStatus(false);
        responseData.setUrL(request.getRequestURL().toString());
        return responseData;
    }
}
