package com.wsn.digitalsandtable.util;

import com.wsn.digitalsandtable.common.RespResult;
import com.wsn.digitalsandtable.entity.Status;
import com.wsn.digitalsandtable.mapper.ResourceMapper;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/16 18:59
 * @Version 1.0*/


/*
@ServerEndpoint("/getStatusByResId")
@Slf4j
@Component
public class WebsocketServer {
    static Logger logger = LoggerFactory.getLogger(WebsocketServer.class);

    private static ApplicationContext context;

    //@Autowired  websocket协议不可直接注入mapper
    private ResourceMapper resourceMapper;

    private Session session;

    private Integer resIdd;

    private boolean status;

    public static void setContext(ApplicationContext applicationContext){
        context = applicationContext;
    }

    @OnOpen
    public void onOpen(Session session) throws IOException, InterruptedException {
        //手动注入mapper
        this.resourceMapper = (ResourceMapper) context.getBean("resourceMapper");
        this.session = session;
        logger.info("有客户端建立连接");
    }

     */
/** 连接关闭时调用的方法
     * *//*

    @OnClose
    public void onClose(){

    }

    //主动关闭连接
    public void close() throws IOException {
        session.close();
    }



     */
/** 收到客户端发送的消息调用的方法
     * *//*


    @OnMessage
    public void onMessage(String resId,Session session) throws IOException, InterruptedException {
        Integer resIddd = Integer.parseInt(resId);
        System.out.println(session.getId());
        if (resIdd == null || !resIdd.equals(resIddd)){
            status = false;
            resIdd = resIddd;
            Thread.sleep(1000);
            status = true;
        }

        while (true){
            while (status){
                sendMessage(resIdd);
                Thread.sleep(1000);
            }
        }
    }

     */
/** 发生错误时调用
     * *//*


    @OnError
    public void onError(Session session,Throwable throwable){
        logger.error("传参不正确或其他错误");
        throwable.printStackTrace();
    }


     */
/** 推送消息
     * *//*


    public void sendMessage(Integer resId) throws IOException {
        Status status = resourceMapper.queryStatusByResId(resId);

        if (status != null){
            JSONObject jsonObject = JSONObject.fromObject(status.getProperty());
            jsonObject.put("name",status.getName());
            this.session.getBasicRemote().sendText(jsonObject.toString());
        }else {
            this.session.getBasicRemote().sendText("未知状态");
        }


    }


}
*/
