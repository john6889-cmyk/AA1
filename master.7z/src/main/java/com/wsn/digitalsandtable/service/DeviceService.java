package com.wsn.digitalsandtable.service;

import com.github.pagehelper.PageInfo;
import com.wsn.digitalsandtable.common.Result;
import com.wsn.digitalsandtable.entity.param.DeviceMoveParam;
import com.wsn.digitalsandtable.entity.param.DevicePageParam;
import com.wsn.digitalsandtable.entity.vo.DeviceVo;
import org.springframework.http.ResponseEntity;

/**
 * @author liwu
 * @date 2022.1.11 18:43
 */
public interface DeviceService {

    PageInfo<DeviceVo> getDevicePageList(DevicePageParam param);

    ResponseEntity<Result> resetDeviceLocation();

    ResponseEntity<Result> moveCampsite(DeviceMoveParam param);
}
