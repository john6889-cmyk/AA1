package com.wsn.digitalsandtable.service;

import com.wsn.digitalsandtable.common.Result;
import com.wsn.digitalsandtable.request.DeviceListRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

public interface ResourceService {

    ResponseEntity<Result> buildingDeviceList(String campName,String buildingName);

    ResponseEntity<Result> cameraDeviceList(String campName,String buildingName);

    ResponseEntity<Result> controlResByCom(Integer resId,String command);

    ResponseEntity<Result> getResourceState(Integer resId);

    ResponseEntity<Result> getResourceStateById(Integer resId);

    ResponseEntity<Result> getOrderList();

    ResponseEntity<Result> getOrderDetail(String id);

    ResponseEntity<Result> getStates();

    ResponseEntity<Result> controlResByPlug(Integer resId, String command) throws InterruptedException;
}
