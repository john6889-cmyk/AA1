package com.wsn.digitalsandtable.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.wsn.digitalsandtable.common.RespResult;
import com.wsn.digitalsandtable.common.Result;
import com.wsn.digitalsandtable.common.StatusCode;
import com.wsn.digitalsandtable.config.TempConfig;
import com.wsn.digitalsandtable.entity.param.DeviceMoveParam;
import com.wsn.digitalsandtable.entity.param.DevicePageParam;
import com.wsn.digitalsandtable.entity.vo.DeviceOriginLocationVo;
import com.wsn.digitalsandtable.entity.vo.DeviceVo;
import com.wsn.digitalsandtable.mapper.DeviceMapper;
import com.wsn.digitalsandtable.service.DeviceService;

import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * @author liwu
 * @date 2022.1.11 19:01
 */
@Service("deviceService")
public class DeviceServiceImpl implements DeviceService {
    @Autowired
    private DeviceMapper deviceMapper;

    @Override
    public PageInfo<DeviceVo> getDevicePageList(DevicePageParam param) {
        PageHelper.startPage(param.getPageNum(), param.getPageSize());
        List<DeviceVo> voList = deviceMapper.selectPageVo(param);
        return new PageInfo<>(voList);
    }

    @Override
    public ResponseEntity<Result> resetDeviceLocation() {
        List<DeviceOriginLocationVo> voList = deviceMapper.getAllDeviceLocation();
        for (DeviceOriginLocationVo vo : voList) {
            deviceMapper.updateDeviceLocation(vo.getResId(), vo.getOriginCampsite(), vo.getOriginDistrict());
        }
        return RespResult.successResult();
    }

    @Override
    public ResponseEntity<Result> moveCampsite(DeviceMoveParam param) {
        if (param == null) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }

        if (param.getResIdList().isEmpty() || StringUtils.isEmpty(param.getCampsite())) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }

        List<Integer> resIdList = param.getResIdList();
        String campsite = param.getCampsite();
        for (Integer resId : resIdList) {
            deviceMapper.updateDeviceCampsite(resId, campsite);
        }
        return RespResult.successResult();
    }

    @Scheduled(cron = "0/1 * * * * ? ")
    public void tempTest() {
        if (TempConfig.change) {
            int id = deviceMapper.selectLastPlugId();
            if (id == TempConfig.plugId) {
                String s = deviceMapper.selectLastPlugProperty(id);
                JSONObject jsonObject = JSONObject.fromObject(s);
                String status = jsonObject.getString("status");
                if (!status.equals(TempConfig.status)) {
                    TempConfig.change = false;
                }
            }
        }
    }

    /**
     * 初始化插座状态
     */
    @PostConstruct
    private void init() {
        TempConfig.plugId = deviceMapper.selectLastPlugId();
        String s = deviceMapper.selectLastPlugProperty(TempConfig.plugId);
        JSONObject jsonObject = JSONObject.fromObject(s);
        TempConfig.status = jsonObject.getString("status");
    }
}
