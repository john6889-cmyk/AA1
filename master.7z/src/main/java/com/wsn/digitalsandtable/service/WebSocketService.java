package com.wsn.digitalsandtable.service;

/**
 * @Author ZhaoMingHui
 * @Date 2021/10/12 13:59
 * @Version 1.0
 */
public interface WebSocketService {
    void pushResourceState(String resId);
}
