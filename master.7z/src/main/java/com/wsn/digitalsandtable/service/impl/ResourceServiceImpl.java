package com.wsn.digitalsandtable.service.impl;

import com.wsn.digitalsandtable.common.RespResult;
import com.wsn.digitalsandtable.common.Result;
import com.wsn.digitalsandtable.common.StatusCode;
import com.wsn.digitalsandtable.config.TempConfig;
import com.wsn.digitalsandtable.entity.Camera;
import com.wsn.digitalsandtable.entity.LogisOrder;
import com.wsn.digitalsandtable.entity.Resource;
import com.wsn.digitalsandtable.entity.Status;
import com.wsn.digitalsandtable.mapper.DeviceMapper;
import com.wsn.digitalsandtable.mapper.ResourceMapper;
import com.wsn.digitalsandtable.service.ResourceService;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resources;
import java.io.File;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/15 15:15
 * @Version 1.0
 */

@Service
@Slf4j
public class ResourceServiceImpl implements ResourceService {

    @Autowired
    private ResourceMapper resourceMapper;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    @Autowired
    private DeviceMapper deviceMapper;

    @Value("${spring.kafka.provider.topic}")
    private String kafkaProviderTopic;

    @Override
    public ResponseEntity<Result> buildingDeviceList(String campName, String buildingName) {

        if (campName == null || "".equals(campName)) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        JSONObject res = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        //查询出设备资源
        List<Resource> resources = resourceMapper.queryResourceListByCamOrDis(campName, buildingName);
        Set<Resource> resources1 = new TreeSet<>(resources);
        resources = new ArrayList<>(resources1);
        /*for (Resource resource : resources) {
            System.out.println(resource);
        }*/
        List<Resource> resourceList = new ArrayList<>(resources);
        if (resources.size() != 0) {
            int i = 1;
            for (Resource resource : resources) {
                JSONObject jsonObject = JSONObject.fromObject(resource);
                if (jsonObject.containsKey("ip") && "".equals(jsonObject.get("ip"))) {
                    jsonObject.remove("ip");
                }

                String type = jsonObject.getString("name");
                String chName = jsonObject.getString("chName");
                Integer resId = Integer.parseInt(jsonObject.getString("resId"));
                Double lon = Double.parseDouble(jsonObject.getString("lon"));
                Double lat = Double.parseDouble(jsonObject.getString("lat"));
                JSONObject object = new JSONObject();
                JSONArray array = new JSONArray();
                array.add(lon);
                array.add(lat);
                if ((!"camera".equals(jsonObject.get("name").toString()) && !"leakageValve".equals(jsonObject.get("name").toString()))
                        && (buildingName == null || "".equals(buildingName))) {
                    object.put("type", "pressureValve");
                } else {
                    object.put("type", type);
                }

                object.put("resId", resId);
                resourceList.remove(resource);

                loop:
                while (true) {
                    for (Resource resource1 : resourceList) {
                        if (resource.getName().equals(resource1.getName())) {
                            object.put("equipmentName", chName + i);
                            i++;
                            break loop;
                        }
                    }
                    object.put("equipmentName", chName + i);
                    i = 1;
                    break;
                }
                object.put("data", array);
                jsonArray.add(object);
            }
        }
        if (jsonArray.size() == 0) {
            return RespResult.getResult(StatusCode.QUERYNULL);
        }
        res.put("data", jsonArray);
        return RespResult.successResult(res);
    }

    @Override
    public ResponseEntity<Result> cameraDeviceList(String campName, String buildingName) {
        if (campName == null || "".equals(campName)) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }

        JSONObject res = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        List<Camera> cameras = resourceMapper.queryCameraListByCamOrDis(campName, buildingName);
        System.out.println(cameras.size());
        if (cameras != null && cameras.size() != 0) {
            int i = 1;
            for (Camera camera : cameras) {
                JSONObject jsonObject = JSONObject.fromObject(camera);
                if (jsonObject.containsKey("ip") && "".equals(jsonObject.get("ip"))) {
                    jsonObject.remove("ip");
                }

                String type = jsonObject.getString("deviceType");
                Integer resId = Integer.parseInt(jsonObject.getString("resId"));
                String brand = jsonObject.getString("brand");
                String model = jsonObject.getString("model");
                String ip = jsonObject.getString("ip");
                String url = jsonObject.getString("url");

                Double lon = Double.parseDouble(jsonObject.getString("lon"));
                Double lat = Double.parseDouble(jsonObject.getString("lat"));

                JSONObject object = new JSONObject();
                JSONArray array = new JSONArray();
                array.add(lon);
                array.add(lat);
                object.put("type", type);
                object.put("resId", resId);
                object.put("brand", brand);
                object.put("model", model);
                object.put("ip", ip);
                object.put("url", url);
                unRealData(object);


                loop:
                while (true) {
                    for (Camera camera1 : cameras) {
                        if (camera.getBrand().equals(camera1.getBrand())) {
                            object.put("equipmentName", type + i);
                            i++;
                            break loop;
                        }
                    }
                    object.put("equipmentName", type + i);
                    i = 1;
                    break;
                }
                object.put("data", array);
                jsonArray.add(object);
            }
        }

        if (jsonArray.size() == 0) {
            return RespResult.getResult(StatusCode.QUERYNULL);
        }
        res.put("data", jsonArray);
        return RespResult.successResult(res);
    }

    //假数据
    private void unRealData(JSONObject object) {
        object.put("deviceCategory", "视频监控系统");
        object.put("deviceType", "IPCam");
    }

    @Override
    public ResponseEntity<Result> controlResByCom(Integer resId, String command) {
        if (resId == null || command == null || resId <= 0) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        Resource resource = resourceMapper.queryResourceByResId(resId);

        if (resource != null) {
            log.info("resource: {}", resource);
            JSONObject object = JSONObject.fromObject(resource.getProperty());
            if (object.get("control") != null) {
                if ("open".equals(command)) {
                    Status status = resourceMapper.queryStatusByResId(resId);
                    if (status != null) {
                        JSONObject temp = JSONObject.fromObject(status.getProperty());
                        if ("open".equals(temp.getString("status"))) {
                            return RespResult.getResult(StatusCode.SUCCESS, "当前状态无需改变");
                        }
                    }
                    JSONObject sendObject = new JSONObject();
                    if ("light".equals(resource.getName())) {
                        sendObject.put("cmd", "control");
                        sendObject.put("model", "yeelight_led_light");
                        sendObject.put("ip", "192.168.15.27");
                        sendObject.put("power", "on");
                    } else if ("lowPressureValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "5");
                    } else if ("midlePressureValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "3");
                    } else if ("highPressureValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "1");
                    } else if ("leakageValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "7");
                    } else if ("windowOpener".equals(resource.getName())) {
                        sendObject.put("cmd", "control");
                        sendObject.put("model", "broadlink_switch");
                        sendObject.put("ip", "192.168.31.100");
                        sendObject.put("slot", "s3");
                        sendObject.put("action", "on");
                    }
                    kafkaTemplate.send(kafkaProviderTopic, sendObject.toString());
                    if (checkIsOk(resId, command)) {
                        log.info("control command: {}", sendObject);
                        return RespResult.getResult(StatusCode.SUCCESS, "成功控制");
                    } else {
                        return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR, "状态未及时改变，请稍后关注控制台，或联系管理员");
                    }
                } else if ("close".equals(command)) {
                    JSONObject sendObject = new JSONObject();
                    Status status = resourceMapper.queryStatusByResId(resId);
                    if (status != null) {
                        JSONObject temp = JSONObject.fromObject(status.getProperty());
                        if ("close".equals(temp.getString("status"))) {
                            return RespResult.getResult(StatusCode.SUCCESS, "当前状态无需改变");
                        }
                    }
                    if ("light".equals(resource.getName())) {
                        sendObject.put("cmd", "control");
                        sendObject.put("model", "yeelight_led_light");
                        sendObject.put("ip", "192.168.15.27");
                        sendObject.put("power", "off");
                    } else if ("lowPressureValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "6");
                    } else if ("midlePressureValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "4");
                    } else if ("highPressureValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "2");
                    } else if ("leakageValve".equals(resource.getName())) {
                        sendObject.put("model", "valve");
                        sendObject.put("value", "8");
                    } else if ("windowOpener".equals(resource.getName())) {
                        sendObject.put("cmd", "control");
                        sendObject.put("model", "broadlink_switch");
                        sendObject.put("ip", "192.168.31.100");
                        sendObject.put("slot", "s3");
                        sendObject.put("action", "off");
                    }
                    kafkaTemplate.send(kafkaProviderTopic, sendObject.toString());
                    //异步线程调用
                    if (checkIsOk(resId, command)) {
                        log.info("control command: {}", sendObject);
                        return RespResult.getResult(StatusCode.SUCCESS, "成功控制");
                    } else {
                        return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR, "状态未及时改变，请稍后关注控制台，或联系管理员");
                    }
                } else {
                    return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR, "当前不支持此命令");
                }
            } else {
                return RespResult.getResult(StatusCode.NO_SUPPORT_CONTROL);
            }
        } else {
            return RespResult.getResult(StatusCode.QUERYNULL);
        }
    }

    @Override
    public ResponseEntity<Result> getResourceState(Integer resId) {
        if (resId == null) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        Status resourceStatus = resourceMapper.queryStatusByResId(resId);
        if (resourceStatus != null) {
            if (resId == 7) {
                String s = resourceStatus.getProperty();
                JSONObject jsonObject = JSONObject.fromObject(s);
                String status = jsonObject.getString("status");
                if (status != null) {
                    TempConfig.status = status;
                }
            }

            JSONObject jsonObject = JSONObject.fromObject(resourceStatus);

            jsonObject.put("property", JSONObject.fromObject(jsonObject.get("property")));
            if (jsonObject.get("name") != null) {
                if ("printer".equals(jsonObject.getString("name"))) {
                    jsonObject.put("deviceCategory", "办公自动化系统");
                    jsonObject.put("deviceType", "打印机");
                    jsonObject.put("brand", "HP");
                    jsonObject.put("model", "officejet 4650");
                    jsonObject.put("version", "未知");
                    jsonObject.put("ip", "1.1.1.1");
                    jsonObject.put("port", "80");
                } else if ("conferenceTerminal".equals(jsonObject.getString("name"))) {
                    jsonObject.put("deviceCategory", "视频会议系统");
                    jsonObject.put("deviceType", "视频会议终端");
                    jsonObject.put("brand", "huawei");
                    jsonObject.put("model", "espace u1960");
                    jsonObject.put("version", "未知");
                }
            }
            return RespResult.successResult(jsonObject);
        } else {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id", "");
            jsonObject.put("name", "");
            jsonObject.put("property", new JSONObject());
            jsonObject.put("resId", "");
            jsonObject.put("vendor", "");
            return RespResult.getResult(StatusCode.QUERYNULL, "查询结果为空", jsonObject);
        }
    }

    @Override
    public ResponseEntity<Result> getResourceStateById(Integer resId) {
        Status resourceStateById = resourceMapper.getResourceStateById(resId);
        return RespResult.getResult(StatusCode.SUCCESS, "查询成功", resourceStateById);
    }

    //持续监测数据库设备状态 控制成功 返回true
    private boolean checkIsOk(Integer resId, String command) {
        if (command == null || resId == null) {
            return false;
        }
        Resource resource = resourceMapper.queryResourceByResId(resId);
        /*灯和阀门的控制*/
        if ("light".equals(resource.getName()) || resource.getName().contains("Valve")) {
            if ("open".equals(command)) {
                for (int i = 0; i < 100; i++) {
                    Status status = resourceMapper.queryStatusByResId(resId);
                    if (status != null) {
                        JSONObject object = JSONObject.fromObject(status.getProperty());
                        if ("open".equals(object.getString("status"))) {
                            return true;
                        }
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else if ("close".equals(command)) {
                for (int i = 0; i < 100; i++) {
                    Status status = resourceMapper.queryStatusByResId(resId);
                    if (status != null) {
                        JSONObject object = JSONObject.fromObject(status.getProperty());
                        if ("close".equals(object.getString("status"))) {
                            return true;
                        }
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            return false;
        }
        JSONObject object = new JSONObject();
        object.put("status", command);
        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resId);
        return true;
    }

    @Override
    public ResponseEntity<Result> getOrderList() {
        List<String> orders = resourceMapper.queryAllOrderDistinct();
        JSONObject res = new JSONObject();
        JSONArray array = new JSONArray();
        if (orders != null && orders.size() != 0) {
            for (int i = 0; i < orders.size(); i++) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("label", orders.get(i));
                jsonObject.put("value", orders.get(i));
                array.add(jsonObject);
            }
            res.put("orderList", array);
            return RespResult.successResult(res);
        }
        return RespResult.getResult(StatusCode.QUERYNULL);
    }

    @Override
    public ResponseEntity<Result> getOrderDetail(String id) {
        if (id == null) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        LogisOrder logisOrder = resourceMapper.queryOrderDetailById(id);
        if (logisOrder != null) {
            JSONObject res = JSONObject.fromObject(logisOrder);
            res.put("qrCode", res.getString("qrCode").replaceAll("\\n", ""));
            System.out.println(res.getString("qrCode"));
            Timestamp ts = new Timestamp(Long.parseLong(res.getString("deliveryTime")));
            String tsStr = "";
            DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            try {
                //方法一
                tsStr = sdf.format(ts);
                //System.out.println(tsStr);
                //方法二
                //tsStr = ts.toString();
                //System.out.println(tsStr);
            } catch (Exception e) {
                e.printStackTrace();
            }

            //运输过程模拟
            JSONArray jsonArray = new JSONArray();
            for (int i = 1; i <= 5; i++) {
                JSONObject object = new JSONObject();
                switch (i) {
                    case 1:
                        object.put("content", "已下单");
                        object.put("timestamp", tsStr);
                        object.put("icon", "el-icon-truck");
                        jsonArray.add(object);
                        break;
                    case 2:
                        object.put("content", "已发货");
                        object.put("timestamp", sdf.format(new Timestamp(Long.parseLong(res.getString("deliveryTime")) + (long) (1000 * 60 * 60 * 24))));
                        object.put("color", "#0bbd87");
                        jsonArray.add(object);
                        break;
                    case 3:
                        object.put("content", res.getString("senderAddress"));
                        object.put("timestamp", sdf.format(new Timestamp(Long.parseLong(res.getString("deliveryTime")) + (long) (1000 * 60 * 60 * 24))));
                        object.put("color", "#0bbd87");
                        jsonArray.add(object);
                        break;
                    case 4:
                        object.put("content", res.getString("userAddress"));
                        object.put("timestamp", sdf.format(new Timestamp(Long.parseLong(res.getString("deliveryTime")) + (long) (3 * 1000 * 60 * 60 * 24))));
                        object.put("color", "#0bbd87");
                        jsonArray.add(object);
                        break;
                    case 5:
                        object.put("content", "已收货");
                        object.put("timestamp", sdf.format(new Timestamp(Long.parseLong(res.getString("deliveryTime")) + (long) (3 * 1000 * 60 * 60 * 24))));
                        object.put("color", "#0bbd870");
                        jsonArray.add(object);
                        break;
                    default:
                        break;
                }
            }

            res.put("activitiesAll", jsonArray);
            res.put("deliveryTime", tsStr);
            return RespResult.successResult(res);
        }
        return RespResult.getResult(StatusCode.QUERYNULL);
    }

    @Override
    public ResponseEntity<Result> getStates() {
        return RespResult.getResult(StatusCode.SUCCESS, "获取成功", resourceMapper.getStates());
    }

    @Override
    public ResponseEntity<Result> controlResByPlug(Integer resId, String command) throws InterruptedException {
        if (command != null && !"".equals(command)) {
            if ("close".equals(command) || "off".equals(command)) {
                command = "off";
            } else {
                command = "on";
            }
            String s1 = deviceMapper.selectLastPlug();
            JSONObject jsonObject1 = JSONObject.fromObject(s1);
            String status1 = jsonObject1.getString("status");
            if (!TempConfig.status.equals(status1)) {
                TempConfig.status = status1;
            }
            if (command.equals(TempConfig.status)) {
                return RespResult.getResult(StatusCode.SUCCESS, "当前状态无需改变");
            } else {
                TempConfig.change = true;
                for (int i = 0; i < 90; i++) {
                    int id = deviceMapper.selectLastPlugId();
                    if (i == 15) {
                        log.info("执行自动控制");
                        if (TempConfig.status.equals("on")) {
                            kafkaTemplate.send("STRENGTHENING_PERCEPTUAL_210914", "{\"cmd\": \"report\", \"model\": \"plug\", \"sid\": \"158d00039ba948\", \"short_id\": 42782, \"data\": \"{\\\"status\\\":\\\"off\\\"}\"}");
                        } else {
                            kafkaTemplate.send("STRENGTHENING_PERCEPTUAL_210914", "{\"cmd\": \"report\", \"model\": \"plug\", \"sid\": \"158d00039ba948\", \"short_id\": 42782, \"data\": \"{\\\"status\\\":\\\"on\\\"}\"}");
                        }
                    }
                    if (id != TempConfig.plugId) {
                        TempConfig.plugId = id;
                        String s = deviceMapper.selectLastPlugProperty(id);
                        JSONObject jsonObject = JSONObject.fromObject(s);
                        String status = jsonObject.getString("status");
                        if (!TempConfig.status.equals(status)) {
                            TempConfig.status = status;
                            TempConfig.change = false;
                            return RespResult.getResult(StatusCode.SUCCESS, "成功控制", TempConfig.status);

                        }
                    }
                    Thread.sleep(500);
                }
                TempConfig.change = false;
                return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR, "当前控制未及时生效");
            }
        } else {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR, "请重新检查参数");
        }
    }
}
