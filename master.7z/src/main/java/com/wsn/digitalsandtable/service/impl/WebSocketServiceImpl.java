package com.wsn.digitalsandtable.service.impl;

import com.wsn.digitalsandtable.entity.Status;
import com.wsn.digitalsandtable.mapper.ResourceMapper;
import com.wsn.digitalsandtable.service.WebSocketService;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


@Service
@Slf4j
public class WebSocketServiceImpl implements WebSocketService {

    @Autowired
    private SimpMessagingTemplate template;

    @Autowired
    private ResourceMapper resourceMapper;

    private List<String> resIds = new ArrayList<>();
    @Override
    public void pushResourceState(String resId) {

        if (resIds.contains(resId)){
            return;
        }
        resIds.add(resId);
        Status status = resourceMapper.queryStatusByResId(Integer.parseInt(resId));
        log.info(resId);
        if (status != null){
            JSONObject jsonObject = JSONObject.fromObject(status.getProperty());
            jsonObject.put("name",status.getName());
            while (true){
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                template.convertAndSend("/topic/" + resId,jsonObject);
            }

        }else {
            template.convertAndSend("/topic/" + resId,"未知状态");
        }
    }
}
