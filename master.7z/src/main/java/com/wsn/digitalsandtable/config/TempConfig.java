package com.wsn.digitalsandtable.config;


public class TempConfig {
    public volatile static int plugId = 0;
    public volatile static boolean change = false;
    //异常是否会被获取和状态
    public volatile static boolean exceptionFlag = false;
    public volatile static String status = "";
    //on/off
    public volatile static String attackStatus = "off";
    public volatile static String exceptionStatus = "off";
    //on/off
    public volatile static String protectionStatus = "off";
    public volatile static String light = "close";

}
