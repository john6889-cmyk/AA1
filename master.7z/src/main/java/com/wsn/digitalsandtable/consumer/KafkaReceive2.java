package com.wsn.digitalsandtable.consumer;

import com.wsn.digitalsandtable.mapper.ResourceMapper;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Optional;

/**
 * @Author ZhaoMingHui
 * @Date 2021/10/13 15:40
 * @Version 1.0
 * <p>
 * 监听物流topic 解析数据并存库
 */
@Component
@Slf4j
public class KafkaReceive2 {

    @Autowired
    private ResourceMapper resourceMapper;

    @KafkaListener(topics = "${spring.kafka.topic.logis}")
    public void listen(ConsumerRecord<?, ?> record) throws IOException {
        log.info("kafka-STRENGTHENING_LOGISTICS_INFORMATION_211010-receive: {}", record.value());
        Optional<?> kafkaMessage = Optional.ofNullable(record.value());
        Object message = kafkaMessage.get();
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("C:\\Users\\Administrator\\Desktop\\detectData.txt", true));
        bufferedWriter.write(message.toString() + "\n");
        bufferedWriter.flush();
        JSONObject jsonObject = JSONObject.fromObject(message.toString());
        log.info("原生json：" + jsonObject);
        //
        Integer id = Integer.parseInt(jsonObject.getString("id"));
        String deliveryTime = jsonObject.getString("deliveryTime");
        String orderStatus = jsonObject.getString("orderStatus");
        String senderAddress = jsonObject.getString("senderAddress");
        String senderName = jsonObject.getString("senderName");
        String senderPhone = jsonObject.getString("senderPhone");
        String userAddress = jsonObject.getString("userAddress");
        String userId = jsonObject.getString("userId");
        String userName = jsonObject.getString("userName");
        String userPhone = jsonObject.getString("userPhone");
        String qrCode = jsonObject.getString("qRCode");

        resourceMapper.insertLogisOrderData(id, deliveryTime, orderStatus, senderAddress, senderName, senderPhone, userAddress, userId, userName, userPhone, qrCode);
    }
}
