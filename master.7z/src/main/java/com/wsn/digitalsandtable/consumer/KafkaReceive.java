package com.wsn.digitalsandtable.consumer;


import com.wsn.digitalsandtable.entity.Resource;
import com.wsn.digitalsandtable.entity.Status;
import com.wsn.digitalsandtable.mapper.DeviceMapper;
import com.wsn.digitalsandtable.mapper.ResourceMapper;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import org.apache.commons.lang.ObjectUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * @ClassName KafkaReceiver
 * @Author ywj
 * @Describe
 * @Date 2019/3/19 0019 19:51
 */
@Component
@Slf4j
public class KafkaReceive {

    @Autowired
    private ResourceMapper resourceMapper;
    @Autowired
    private DeviceMapper deviceMapper;
    private static Resource resourceLowValve;
    private static Resource resourceMediumValve;
    private static Resource resourceHighValve;
    private static Resource resourceLeakValve;

    private static List<Resource> resourceMotionXiaomi;
    private static List<Resource> resourceMotionAgara;

    private static List<Resource> resourceMagnetXiaomi;
    private static List<Resource> resourceSensorHTXiaomi;
    private static List<Resource> resourceSmokeXiaomi;
    private static List<Resource> resourceSensorWleak;

    private static List<Resource> resourceBroadlinkSensor;
    private static List<Resource> resourceBroadlinkSwitch;
    private static List<Resource> resourceYeelightLedLight;


        @KafkaListener(topics = {"${spring.kafka.topic}"})
    public void listen(ConsumerRecord<?, ?> record) throws IOException, InterruptedException {
        log.info("kafka-STRENGTHENING_PERCEPTUAL_210914-receive: {}", record.value());

        if (record.value() == "" || record.value() == null) {
            return;
        }
        JSONObject jsonObject;
        try {
            jsonObject = JSONObject.fromObject(record.value());
        } catch (JSONException e) {
            log.error("收到非法格式消息: {}", e.getMessage());
            return;
        }
        if (jsonObject.get("model") != null && jsonObject.get("data") != null) {
            if (JSONObject.fromObject(jsonObject.get("data")).get("alarm") != null) {
                return;
            }
        }
        Object name = jsonObject.get("name");
        if (name != null) {
            if ("燃气平台".equals(name)) {
                updateValueState(jsonObject);
                return;
            }
        }

        Object model = jsonObject.get("model");
        if (model != null) {
            updateResourceState(jsonObject);
        }
    }

    // {"ip": "192.168.1.41", "brand": "华为", "name": "终端", "model": "TE50", "status": "calling"}
    private void updateConferenceTerminal(JSONObject jsonObject) {
        String ip = jsonObject.getString("ip");
        String brand = jsonObject.getString("brand");
        Resource resource = resourceMapper.queryConferenceTerminalByVendorAndIp(brand, ip);
        if (resource == null) {
            // 查找不到设备直接退出
            return;
        }
        Status resourceStatus = resourceMapper.queryStatusByResId(resource.getResId());
        String currentStatusStr = Objects.equals(jsonObject.getString("status"), "calling") ? "true" : "false";
        boolean currentStatus = "true".equals(currentStatusStr);
        JSONObject object = new JSONObject();
        object.put("status", currentStatus);
        object.put("ip", ip);
        if (resourceStatus == null) {
            resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
        } else {
            JSONObject savedProperty = JSONObject.fromObject(JSONObject.fromObject(resourceStatus.getProperty()));
            String savedStatusStr = savedProperty.getString("status");
            if (!Objects.equals(savedStatusStr, currentStatusStr)) {
                resourceMapper.updateDeviceStatus(resourceStatus.getId(), resource.getVendor(),
                        resource.getName(), object.toString(), resource.getResId());
            }
        }
    }

    //更新阀门资源数据状态
    //低压阀门状态数据  {"status":"open/close","in_pressure":204,"out_pressure":205}
    //中压阀门状态数据  {"status":"open/close","temperature":22,"pressure":33}
    //高压阀门状态数据  {"status":"open/close","flow":800,"temperature":22,"in_pressure":33,"out_pressure":33}
    //泄露阀门状态数据  {"status":"open/close"}
    private void updateValueState(JSONObject tarJson) {
        if (resourceLowValve == null || resourceMediumValve == null || resourceHighValve == null || resourceLeakValve == null) {
            resourceLowValve = resourceMapper.queryValveByName("lowPressureValve");
            resourceMediumValve = resourceMapper.queryValveByName("midlePressureValve");
            resourceHighValve = resourceMapper.queryValveByName("highPressureValve");
            resourceLeakValve = resourceMapper.queryValveByName("leakAgeValve");
        }

        //状态改变才存库  低压fa
        Status status = resourceMapper.queryStatusByResId(resourceLowValve.getResId());
        if (status == null) {
            JSONObject object = new JSONObject();
            object.put("in_pressure", Double.parseDouble(tarJson.getString("low_pipeline_in_pressure")));
            object.put("out_pressure", Double.parseDouble(tarJson.getString("low_pipeline_out_pressure")));
            if ("1".equals(tarJson.getString("low_pressure_valve_status"))) {
                object.put("status", "open");
            } else {
                object.put("status", "close");
            }
            resourceMapper.insertDeviceState(resourceLowValve.getVendor(), resourceLowValve.getName(), object.toString(), resourceLowValve.getResId());
        } else {
            JSONObject object = JSONObject.fromObject(status.getProperty());
            if ("open".equals(object.getString("status"))) {
                if ("0".equals(tarJson.getString("low_pressure_valve_status")) || !tarJson.getString("low_pipeline_in_pressure").equals(object.getString("in_pressure"))
                        || !tarJson.getString("low_pipeline_out_pressure").equals(object.getString("out_pressure"))) {
                    object.put("in_pressure", Double.parseDouble(tarJson.getString("low_pipeline_in_pressure")));
                    object.put("out_pressure", Double.parseDouble(tarJson.getString("low_pipeline_out_pressure")));
                    if ("1".equals(tarJson.getString("low_pressure_valve_status"))) {
                        object.put("status", "open");
                    } else {
                        object.put("status", "close");
                    }
                }
            } else {
                if ("1".equals(tarJson.getString("low_pressure_valve_status")) || !tarJson.getString("low_pipeline_in_pressure").equals(object.getString("in_pressure"))
                        || !tarJson.getString("low_pipeline_out_pressure").equals(object.getString("out_pressure"))) {
                    object.put("in_pressure", Double.parseDouble(tarJson.getString("low_pipeline_in_pressure")));
                    object.put("out_pressure", Double.parseDouble(tarJson.getString("low_pipeline_out_pressure")));
                    if ("1".equals(tarJson.getString("low_pressure_valve_status"))) {
                        object.put("status", "open");
                    } else {
                        object.put("status", "close");
                    }
                }
            }
            resourceMapper.updateDeviceStatus(status.getId(), status.getVendor(), status.getName(), object.toString(), status.getResId());
        }


        //中压阀
        Status status1 = resourceMapper.queryStatusByResId(resourceMediumValve.getResId());
        if (status1 == null) {
            JSONObject mediumValveState = new JSONObject();
            mediumValveState.put("temperature", Double.parseDouble(tarJson.get("medium_pipeline_temperature").toString()));
            mediumValveState.put("in_pressure", Double.parseDouble(tarJson.get("medium_pipeline_pressure").toString()));
            mediumValveState.put("out_pressure", 0);
            if ("1".equals(tarJson.get("medium_pressure_valve_status"))) {
                mediumValveState.put("status", "open");
            } else {
                mediumValveState.put("status", "close");
            }
            resourceMapper.insertDeviceState(resourceMediumValve.getVendor(), resourceMediumValve.getName(), mediumValveState.toString(), resourceMediumValve.getResId());
        } else {
            JSONObject object = JSONObject.fromObject(status1.getProperty());
            object.put("out_pressure", 0);
            if ("open".equals(object.getString("status"))) {
                if ("0".equals(tarJson.getString("medium_pressure_valve_status")) || !tarJson.getString("medium_pipeline_temperature").equals(object.getString("temperature"))
                        || !tarJson.getString("medium_pipeline_pressure").equals(object.getString("in_pressure"))) {
                    object.put("temperature", Double.parseDouble(tarJson.get("medium_pipeline_temperature").toString()));
                    object.put("in_pressure", Double.parseDouble(tarJson.get("medium_pipeline_pressure").toString()));
                    if ("1".equals(tarJson.getString("medium_pressure_valve_status"))) {
                        object.put("status", "open");
                    } else {
                        object.put("status", "close");
                    }
                }
            } else {
                if ("1".equals(tarJson.getString("medium_pressure_valve_status")) || !tarJson.getString("medium_pipeline_temperature").equals(object.getString("temperature"))
                        || !tarJson.getString("medium_pipeline_pressure").equals(object.getString("in_pressure"))) {
                    object.put("temperature", Double.parseDouble(tarJson.get("medium_pipeline_temperature").toString()));
                    object.put("in_pressure", Double.parseDouble(tarJson.get("medium_pipeline_pressure").toString()));
                    if ("1".equals(tarJson.getString("medium_pressure_valve_status"))) {
                        object.put("status", "open");
                    } else {
                        object.put("status", "close");
                    }
                }
            }

            resourceMapper.updateDeviceStatus(status1.getId(), status1.getVendor(), status1.getName(), object.toString(), status1.getResId());
        }

        //高压阀
        Status status2 = resourceMapper.queryStatusByResId(resourceHighValve.getResId());
        if (status2 == null) {
            JSONObject statusProperty = new JSONObject();
            statusProperty.put("flow", Double.parseDouble(tarJson.get("high_pipeline_flow").toString()));
            statusProperty.put("temperature", Double.parseDouble(tarJson.get("high_pipeline_temperature").toString()));
            statusProperty.put("in_pressure", Double.parseDouble(tarJson.get("high_pipeline_in_pressure").toString()));
            statusProperty.put("out_pressure", Double.parseDouble(tarJson.get("high_pipeline_out_pressure").toString()));
            if ("1".equals(tarJson.get("high_pressure_valve_status"))) {
                statusProperty.put("status", "open");
            } else {
                statusProperty.put("status", "close");
            }
            resourceMapper.insertDeviceState(resourceHighValve.getVendor(), resourceHighValve.getName(), statusProperty.toString(), resourceHighValve.getResId());
        } else {
            JSONObject object = JSONObject.fromObject(status2.getProperty());
            if ("open".equals(object.getString("status"))) {
                if ("0".equals(tarJson.getString("high_pressure_valve_status"))
                        || !tarJson.getString("high_pipeline_flow").equals(object.getString("flow"))
                        || !tarJson.getString("high_pipeline_temperature").equals(object.getString("temperature"))
                        || !tarJson.getString("high_pipeline_in_pressure").equals(object.getString("in_pressure"))
                        || !tarJson.getString("high_pipeline_out_pressure").equals(object.getString("out_pressure"))) {
                    object.put("flow", Double.parseDouble(tarJson.get("high_pipeline_flow").toString()));
                    object.put("temperature", Double.parseDouble(tarJson.get("high_pipeline_temperature").toString()));
                    object.put("in_pressure", Double.parseDouble(tarJson.get("high_pipeline_in_pressure").toString()));
                    object.put("out_pressure", Double.parseDouble(tarJson.get("high_pipeline_out_pressure").toString()));
                    if ("1".equals(tarJson.getString("high_pressure_valve_status"))) {
                        object.put("status", "open");
                    } else {
                        object.put("status", "close");
                    }
                }
            } else {
                if ("1".equals(tarJson.getString("high_pressure_valve_status"))
                        || !tarJson.getString("high_pipeline_flow").equals(object.getString("flow"))
                        || !tarJson.getString("high_pipeline_temperature").equals(object.getString("temperature"))
                        || !tarJson.getString("high_pipeline_in_pressure").equals(object.getString("in_pressure"))
                        || !tarJson.getString("high_pipeline_out_pressure").equals(object.getString("out_pressure"))) {
                    object.put("flow", Double.parseDouble(tarJson.get("high_pipeline_flow").toString()));
                    object.put("temperature", Double.parseDouble(tarJson.get("high_pipeline_temperature").toString()));
                    object.put("in_pressure", Double.parseDouble(tarJson.get("high_pipeline_in_pressure").toString()));
                    object.put("out_pressure", Double.parseDouble(tarJson.get("high_pipeline_out_pressure").toString()));
                    if ("1".equals(tarJson.getString("high_pressure_valve_status"))) {
                        object.put("status", "open");
                    } else {
                        object.put("status", "close");
                    }
                }
            }
            resourceMapper.updateDeviceStatus(status2.getId(), status2.getVendor(), status2.getName(), object.toString(), status2.getResId());
        }

        //泄露阀
        Status leakStatus = resourceMapper.queryStatusByResId(resourceLeakValve.getResId());
        if (leakStatus == null) {
            JSONObject object = new JSONObject();
            object.put("out_pressure", 0);
            object.put("in_pressure", 0);
            if ("1".equals(tarJson.getString("leak_valve_status"))) {
                object.put("status", "open");
            } else {
                object.put("status", "close");
            }
            resourceMapper.insertDeviceState(resourceLeakValve.getVendor(), resourceLeakValve.getName(), object.toString(), resourceLeakValve.getResId());
        } else {
            JSONObject object = JSONObject.fromObject(leakStatus.getProperty());
            if ("open".equals(object.getString("status"))) {
                if ("0".equals(tarJson.getString("leak_valve_status"))) {
                    object.put("status", "close");
                }
            } else {
                if ("1".equals(tarJson.getString("leak_valve_status"))) {
                    object.put("status", "open");
                }
            }
            resourceMapper.updateDeviceStatus(leakStatus.getId(), leakStatus.getVendor(), leakStatus.getName(), object.toString(), leakStatus.getResId());
        }
    }

    private void updateResourceState(JSONObject tarJson) {
//        if (resourceMotionXiaomi == null || resourceMotionAgara == null
//                || resourceMagnetXiaomi == null || resourceSensorHTXiaomi == null
//                || resourceSmokeXiaomi == null || resourceSensorWleak == null
//                || resourceBroadlinkSensor == null || resourceBroadlinkSwitch == null
//                || resourceYeelightLedLight == null) {
        if (resourceMotionAgara == null || resourceYeelightLedLight == null || resourceSensorHTXiaomi == null) {
            //resourceMotionXiaomi = resourceMapper.queryMotionResourceByVendorAndName("小米", "人体传感器");
            //现在只需要三个信息 灯
            //人体传感器
            //温湿度传感器
            resourceMotionAgara = resourceMapper.queryMotionResourceByVendorAndName("Agara", "人体传感器");
            resourceYeelightLedLight = resourceMapper.queryMotionResourceByVendorAndName("YeeLight", "light");
            resourceSensorHTXiaomi = resourceMapper.queryMotionResourceByVendorAndName("sensor_ht", "温湿传感器");
            resourceSensorHTXiaomi = resourceMapper.queryMotionResourceByVendorAndName("weather.v1", "温湿传感器");

//            resourceMagnetXiaomi = resourceMapper.queryResourceByNameAndDistrictAndCampsite("门窗传感器", "", "营区A");
//            resourceMagnetXiaomi.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("门窗传感器", "", "营区B"));
//            resourceSensorHTXiaomi = resourceMapper.queryResourceByNameAndDistrictAndCampsite("temHumSensor", "营房", "营区A");
//            resourceSensorHTXiaomi.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("temHumSensor", "营房", "营区B"));
//            resourceSmokeXiaomi = resourceMapper.queryResourceByNameAndDistrictAndCampsite("alarm", "仓库", "营区A");
//            resourceSmokeXiaomi.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("alarm", "仓库", "营区B"));
//            resourceBroadlinkSensor = resourceMapper.queryResourceByNameAndDistrictAndCampsite("environmentDetection", "营房", "营区A");
//            resourceBroadlinkSwitch = resourceMapper.queryResourceByNameAndDistrictAndCampsite("智能插排", "", "营区A");
//            resourceBroadlinkSwitch.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("智能插排", "", "营区B"));
//            resourceYeelightLedLight = resourceMapper.queryResourceByNameAndDistrictAndCampsite("light", "营房", "营区A");
//            resourceYeelightLedLight.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("light", "办公室", "营区A"));
//            resourceYeelightLedLight.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("light", "仓库", "营区A"));
//            resourceYeelightLedLight.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("light", "仓库", "营区B"));
//            resourceYeelightLedLight.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("light", "营房", "营区B"));
//            resourceBroadlinkSensor.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("environmentDetection", "仓库", "营区A"));
//            resourceBroadlinkSensor.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("environmentDetection", "仓库", "营区B"));
//            resourceBroadlinkSensor.addAll(resourceMapper.queryResourceByNameAndDistrictAndCampsite("environmentDetection", "营房", "营区B"));
        }
        String model = tarJson.getString("model");
        String name = (String) tarJson.getOrDefault("name", null);
        log.info("model：" + model);
        if (Objects.equals(name, "终端")) {
            // 会议终端设备单独判断
            updateConferenceTerminal(tarJson);
            return;
        }
        switch (model) {
            case "sensor_motion.aq2":
                updateMotionState(tarJson);
                break;
//            case "magnet":
//                updateMagnetState(tarJson);
//                break;
            case "sensor_ht":
            case "weather.v1":
                updateSensorHTState(tarJson);
                break;
//            case "smoke":
//                updateSmokeAlarm(tarJson);
//                break;
//            case "sensor_wleak.aq1":
//                updateSensorWleak(tarJson);
//                break;
//            case "broadlink_switch":
//                updateBroadlinkSwitch(tarJson);
//                break;
//            case "broadlink_sensor":
//                updateBroadlinkSensor(tarJson);
//                break;
            case "yeelight_led_light":
                updateYeeLight(tarJson);
                break;

            //天然气
            case "natgas":
            case "plug":
                updateNatgas(tarJson);
                break;
            default:
                log.info("未知设备");
        }
    }

    /**
     * 天然气报警器
     *
     * @param jsonObject 报警器消息
     */
    private void updateNatgas(JSONObject jsonObject) {
        String sid = jsonObject.getString("sid");
        JSONObject tempJsonObject = JSONObject.fromObject(jsonObject.get("data"));
        Status status = resourceMapper.queryStatusBysid(sid);
        if (status == null) {
            throw new RuntimeException("当前设备信息不存在");
        } else {
            if (status.getResId() == 7) {
                String s = deviceMapper.selectLastPlugProperty(7);
                String status1 = JSONObject.fromObject(s).getString("status");
                String status2 = tempJsonObject.getString("status");
                if (status1 != null && !status1.equals(status2)) {
                    resourceMapper.insertDeviceState(status.getVendor(), status.getName(), tempJsonObject.toString(), status.getResId());
                }
            } else {
                resourceMapper.insertDeviceState(status.getVendor(), status.getName(), tempJsonObject.toString(), status.getResId());
            }
        }
    }
//    private void updatePlug(JSONObject jsonObject) {
//        String sid = jsonObject.getString("sid");
//        JSONObject tempJsonObject = JSONObject.fromObject(jsonObject.get("data"));
//        Status status = resourceMapper.queryStatusBysid(sid);
//        if (status == null) {
//            throw new RuntimeException("当前设备信息不存在");
//        } else {
//            resourceMapper.insertDeviceState(status.getVendor(), status.getName(), tempJsonObject.toString(), status.getResId());
//        }
//    }

    //人体传感器 {"status":true}
    private void updateMotionState(JSONObject jsonObject) {
        jsonObject = JSONObject.fromObject(jsonObject.get("data"));

        for (Resource resource : resourceMotionAgara) {
            Status motionStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (motionStatus == null) {
                JSONObject object = new JSONObject();
                if (jsonObject.containsKey("no_motion")) {
                    object.put("status", false);
                } else {
                    object.put("status", true);
                    object.put("message", "有人移动,光照是：" + jsonObject.get("lux"));
                }
                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                //resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
            } else {
                JSONObject sta = JSONObject.fromObject(motionStatus.getProperty());
                if (jsonObject.containsKey("no_motion")) {
                    sta.put("status", false);
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), sta.toString(), resource.getResId());
                    ////resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), sta.toString(), resource.getResId());
                } else {
                    if (jsonObject.containsKey("lux")) {
                        sta.put("status", true);
                        sta.put("message", "有人移动,光照是：" + jsonObject.get("lux"));
                        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), sta.toString(), resource.getResId());
                        //resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), sta.toString(), resource.getResId());
                    }
                }

            }
        }

    }

    //门窗传感器 {"status":"open/close"}
    // {"cmd":"report", "model":"magnet", "sid":"xxx", "short_id": 43803, "data":"{\\"status\\":\\"close\\"}"}
    private void updateMagnetState(JSONObject jsonObject) {
        jsonObject = JSONObject.fromObject(jsonObject.get("data"));
        String status = jsonObject.getString("status");
        List<Resource> magnetXiaomi = resourceMapper.queryResourceByNameAndDistrictAndCampsite("doorSensor", "", "营区A");
        for (Resource resource : magnetXiaomi) {
            Status magnetStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (magnetStatus == null) {
                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), jsonObject.toString(), resource.getResId());
            } else {
                JSONObject object = JSONObject.fromObject(magnetStatus.getProperty());
                if (!ObjectUtils.equals(object.getString("status"), status)) {
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                }
                if (!object.getString("status").equals(status)) {
                    object.put("status", status);
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                }
            }
        }
    }

    //温湿度传感器 {"temperature":2.2,"humidity":2.2}
    private void updateSensorHTState(JSONObject jsonObject) {
        for (Resource resource : resourceSensorHTXiaomi) {
            Status sensorHTStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (sensorHTStatus == null) {
                JSONObject object = new JSONObject();
                JSONObject data = jsonObject.getJSONObject("data");
                if (data != null) {
                    if (data.get("temperature") != null) {
                        Double d = Double.parseDouble(data.getString("temperature")) / 100;
                        object.put("temperature", d);
                        object.put("humidity", "");
                        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                    } else {
                        if (jsonObject.get("humidity") != null) {
                            String d = Double.parseDouble(data.getString("humidity")) / 100 + "";
                            object.put("temperature", 0.0);
                            object.put("humidity", d);
                            resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                        }
                    }
                }
            } else {
                JSONObject object = JSONObject.fromObject(sensorHTStatus.getProperty());
                JSONObject data = jsonObject.getJSONObject("data");
                if (data != null) {
                    if (data.get("temperature") != null) {
                        if (!object.getString("temperature").equals(data.getString("temperature"))) {
                            Double d = Double.parseDouble(data.getString("temperature")) / 100;
                            object.put("temperature", d);
                            resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                        }
                    } else {
                        if (data.get("humidity") != null) {
                            if (!object.getString("humidity").equals(data.getString("humidity"))) {
                                String d = Double.parseDouble(data.getString("humidity")) / 100 + "";
                                object.put("humidity", d);
                                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                            }
                        }
                    }
                }
            }
        }
    }

    //烟雾报警器 {"status":true}
    private void updateSmokeAlarm(JSONObject jsonObject) {
        for (Resource resource : resourceSmokeXiaomi) {
            Status smokeAlarmStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (smokeAlarmStatus == null) {
                JSONObject object = new JSONObject();
                if ("smoke".equals(jsonObject.getString("status"))) {
                    object.put("status", true);
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                } else {
                    object.put("status", false);
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                }
            } else {
                JSONObject object = JSONObject.fromObject(smokeAlarmStatus.getProperty());
                if ("smoke".equals(jsonObject.getString("status"))) {
                    if ("false".equals(object.getString("status"))) {
                        object.put("status", true);
                        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                    }
                } else {
                    if ("true".equals(object.getString("status"))) {
                        object.put("status", false);
                        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                    }
                }
            }
        }

    }

    //水浸传感器 {"status":true}
    private void updateSensorWleak(JSONObject jsonObject) {
        JSONObject data = JSONObject.fromObject(jsonObject.get("data"));
        String statusStr = data.getString("status");
        List<Resource> resourceList = resourceMapper.queryResourceByChName("水浸传感器");

        JSONObject object = new JSONObject();
        boolean currentStatus = "leak".equals(statusStr);
        object.put("status", currentStatus);

        for (Resource resource : resourceList) {
            Status sensorWleakStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (sensorWleakStatus == null) {
                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
            } else {
                JSONObject savedProperty = JSONObject.fromObject(sensorWleakStatus.getProperty());
                boolean savedStatus = savedProperty.getBoolean("status");
                if (savedStatus != currentStatus) {
                    Integer id = sensorWleakStatus.getId();
                    resourceMapper.updateDeviceStatus(id, resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                }
            }
        }
    }

    //环境检测仪 {"temperature":2.2,"humidity":2.2,"light":"优","air_quality":"黑暗","noise":"寂静"}
    private void updateBroadlinkSensor(JSONObject jsonObject) {
        for (Resource resource : resourceBroadlinkSensor) {
            Status broadlinkSensorStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (broadlinkSensorStatus == null) {
                JSONObject object = new JSONObject();
                Double temperature = Double.parseDouble(jsonObject.getString("temperature"));
                String humidity = Double.parseDouble(jsonObject.getString("humidity")) + "";
                Integer i = Integer.parseInt(jsonObject.getString("light"));
                String light = null;
                switch (i) {
                    case 0:
                        light = "黑暗";
                        break;
                    case 1:
                        light = "昏暗";
                        break;
                    case 2:
                        light = "正常";
                        break;
                    case 3:
                        light = "亮";
                        break;
                    default:
                        log.info("未知亮度");
                }
                Integer i2 = Integer.parseInt(jsonObject.getString("air_quality"));
                String air_quality = null;
                switch (i2) {
                    case 0:
                        air_quality = "优";
                        break;
                    case 1:
                        air_quality = "良";
                        break;
                    case 2:
                        air_quality = "正常";
                        break;
                    case 3:
                        air_quality = "差";
                        break;
                    default:
                        log.info("未知空气质量");
                }
                Integer i3 = Integer.parseInt(jsonObject.getString("noise"));
                String noise = null;
                switch (i3) {
                    case 0:
                        noise = "寂静";
                        break;
                    case 1:
                        noise = "正常";
                        break;
                    case 2:
                        noise = "吵闹";
                        break;
                }
                object.put("temperature", temperature);
                object.put("humidity", humidity);
                object.put("light", light);
                object.put("air_quality", air_quality);
                object.put("noise", noise);
                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
            } else {
                JSONObject object = JSONObject.fromObject(broadlinkSensorStatus.getProperty());
                if (!object.getString("temperature").equals(jsonObject.getString("temperature"))
                        || !object.getString("humidity").equals(jsonObject.getString("humidity"))
                        || !object.getString("light").equals(jsonObject.getString("light"))
                        || !object.getString("air_quality").equals(jsonObject.getString("air_quality"))
                        || !object.getString("noise").equals(jsonObject.getString("noise"))) {
                    Double temperature = Double.parseDouble(jsonObject.getString("temperature"));
                    String humidity = Double.parseDouble(jsonObject.getString("humidity")) + "";
                    Integer i = Integer.parseInt(jsonObject.getString("light"));
                    String light = null;
                    switch (i) {
                        case 0:
                            light = "黑暗";
                            break;
                        case 1:
                            light = "昏暗";
                            break;
                        case 2:
                            light = "正常";
                            break;
                        case 3:
                            light = "亮";
                            break;
                        default:
                            log.info("未知亮度");
                    }
                    Integer i2 = Integer.parseInt(jsonObject.getString("air_quality"));
                    String air_quality = null;
                    switch (i2) {
                        case 0:
                            air_quality = "优";
                            break;
                        case 1:
                            air_quality = "良";
                            break;
                        case 2:
                            air_quality = "正常";
                            break;
                        case 3:
                            air_quality = "差";
                            break;
                        default:
                            log.info("未知空气质量");
                    }
                    Integer i3 = Integer.parseInt(jsonObject.getString("noise"));
                    String noise = null;
                    switch (i3) {
                        case 0:
                            noise = "寂静";
                            break;
                        case 1:
                            noise = "正常";
                            break;
                        case 2:
                            noise = "吵闹";
                            break;
                        default:
                            log.info("未知噪音");
                    }
                    object.put("temperature", temperature);
                    object.put("humidity", humidity);
                    object.put("light", light);
                    object.put("air_quality", air_quality);
                    object.put("noise", noise);
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                }
            }
        }

    }

    //插排 {"ip":"","s1":"on/off","s2":"on/off","s3":"on/off","s4":"on/off"}
    private void updateBroadlinkSwitch(JSONObject jsonObject) {
        for (Resource resource : resourceBroadlinkSwitch) {
            Status broadlinkSwitchStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (broadlinkSwitchStatus == null) {
                JSONObject object = new JSONObject();
                object.put("ip", jsonObject.getString("ip"));
                object.put("s1", jsonObject.getString("s1"));
                object.put("s2", jsonObject.getString("s2"));
                object.put("s3", jsonObject.getString("s3"));
                object.put("s4", jsonObject.getString("s4"));
                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
            } else {
                JSONObject object = JSONObject.fromObject(broadlinkSwitchStatus.getProperty());
                if (!object.getString("ip").equals(jsonObject.getString("ip"))
                        || !object.getString("s1").equals(jsonObject.getString("s1"))
                        || !object.getString("s2").equals(jsonObject.getString("s2"))
                        || !object.getString("s3").equals(jsonObject.getString("s3"))
                        || !object.getString("s4").equals(jsonObject.getString("s4"))) {
                    object.put("ip", jsonObject.getString("ip"));
                    object.put("s1", jsonObject.getString("s1"));
                    object.put("s2", jsonObject.getString("s2"));
                    object.put("s3", jsonObject.getString("s3"));
                    object.put("s4", jsonObject.getString("s4"));
                    resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                }
            }
        }

    }

    //灯 {"ip":"","status":"open/close"}
    private void updateYeeLight(JSONObject jsonObject) {
        log.info("updateYeeLight: {}", jsonObject);
        for (Resource resource : resourceYeelightLedLight) {
            Status yeeLightStatus = resourceMapper.queryStatusByResId(resource.getResId());
            if (yeeLightStatus == null) {
                JSONObject object = new JSONObject();
                object.put("ip", jsonObject.getString("ip"));
                if ("on".equals(jsonObject.getString("power"))) {
                    object.put("status", "open");
                } else {
                    object.put("status", "close");
                }
                resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
            } else {
                JSONObject object = JSONObject.fromObject(yeeLightStatus.getProperty());
                if ("on".equals(jsonObject.getString("power"))) {
                    if ("close".equals(object.getString("status")) || !object.getString("ip").equals(jsonObject.getString("ip"))) {
                        object.put("ip", jsonObject.getString("ip"));
                        object.put("status", "open");
                        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                    }
                } else {
                    if ("open".equals(object.getString("status")) || !object.getString("ip").equals(jsonObject.getString("ip"))) {
                        object.put("ip", jsonObject.getString("ip"));
                        object.put("status", "close");
                        resourceMapper.insertDeviceState(resource.getVendor(), resource.getName(), object.toString(), resource.getResId());
                    }
                }
            }
        }
    }
}