package com.wsn.digitalsandtable.common;

import lombok.Getter;
import lombok.Setter;

/**
 * @Author: xiaochuan
 * @Date: 2019/10/11 9:34
 * @Description: 统一的返回结果
 */

public class Result {
    @Getter
    private int statusCode;
    @Getter
    @Setter
    private String message;
    @Getter
    @Setter
    private Object data;

    public Result(com.wsn.digitalsandtable.common.StatusCode statusCode, String message) {
        this.statusCode = statusCode.getCode();
        this.message = message;
    }

    public Result(com.wsn.digitalsandtable.common.StatusCode statusCode, String message, Object data) {
        this.statusCode = statusCode.getCode();
        this.message = message;
        this.data = data;
    }
}
