package com.wsn.digitalsandtable.common;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

/**
 * @Author: xiaochuan
 * @Date: 2019/10/11 9:53
 * @Description: 结果集封装类，通过调用静态方法直接获取到responseEntity
 */
public class RespResult {
    private static HttpStatus ok = HttpStatus.OK;
    public static ResponseEntity<Result> failResult() {
        return new ResponseEntity<>(new Result(StatusCode.FAILURE, StatusCode.FAILURE.getMsg()), ok);
    }
    public static ResponseEntity<Result> failResult(Object data) {
        return new ResponseEntity<>(new Result(StatusCode.FAILURE, StatusCode.FAILURE.getMsg(), data), ok);
    }
    public static ResponseEntity<Result> failResult(String message) {
        return new ResponseEntity<>(new Result(StatusCode.FAILURE, message), ok);
    }

    public static ResponseEntity<Result> successResult() {
        return new ResponseEntity<>(new Result(StatusCode.SUCCESS, StatusCode.SUCCESS.getMsg()), ok);
    }
    public static ResponseEntity<Result> successResult(Object data) {
        return new ResponseEntity<>(new Result(StatusCode.SUCCESS, StatusCode.SUCCESS.getMsg(), data), ok);
    }

    public static ResponseEntity<Result> getResult(StatusCode statusCode) {
        return new ResponseEntity<>(new Result(statusCode, statusCode.getMsg()), ok);
    }
    public static ResponseEntity<Result> getResult(StatusCode statusCode, String message) {
        return new ResponseEntity<>(new Result(statusCode, message), ok);
    }
    public static ResponseEntity<Result> getResult(StatusCode statusCode, String message, Object data) {
        return new ResponseEntity<>(new Result(statusCode, message, data), ok);
    }
    public static ResponseEntity<Result> getResult(Result result) {
        return new ResponseEntity<>(result, ok);
    }

}
