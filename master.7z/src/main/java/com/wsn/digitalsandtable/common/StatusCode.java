package com.wsn.digitalsandtable.common;

import lombok.Getter;

/**
 * @Author: xiaochuan
 * @Date: 2019/10/11 9:36
 * @Description: 系统状态码
 */
public enum StatusCode {

    SUCCESS(200, "请求成功"),

    FAILURE(500, "服务器异常"),

    /*UNKNOW_ERROR(10000, "未知错误"),*/
    QUERYNULL(200,"查询结果为空"),

    NO_SUPPORT_CONTROL(405,"该资源不支持控制"),

    PARAMS_CHECK_ERROR(405, "参数不正确");




    @Getter
    private int code;
    @Getter
    private String msg;

    StatusCode(int code,String msg) {
        this.code = code;
        this.msg = msg;
    }
}