package com.wsn.digitalsandtable.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wsn.digitalsandtable.common.RespResult;
import com.wsn.digitalsandtable.common.Result;
import com.wsn.digitalsandtable.common.StatusCode;
import com.wsn.digitalsandtable.config.TempConfig;
import com.wsn.digitalsandtable.entity.Status;
import com.wsn.digitalsandtable.mapper.ResourceMapper;
import com.wsn.digitalsandtable.request.ControlRequest;
import com.wsn.digitalsandtable.request.DeviceListRequest;
import com.wsn.digitalsandtable.service.ResourceService;
import com.wsn.digitalsandtable.service.WebSocketService;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/15 15:05
 * @Version 1.0
 */

@RestController
@RequestMapping("/smartCamp")
@CrossOrigin
@Slf4j
public class ResourceController {

    @Autowired
    private ResourceService resourceService;

    @Autowired
    private ResourceMapper resourceMapper;

    @Autowired
    private WebSocketService webSocketService;

    @PostMapping("/buildingDeviceList")
    public ResponseEntity<Result> buildingDeviceList(@RequestBody DeviceListRequest deviceListRequest) {
        return resourceService.buildingDeviceList(deviceListRequest.getCampName(), deviceListRequest.getBuildingName());
    }

    @PostMapping("/getResourceState")
    public ResponseEntity<Result> getResourceState(@RequestBody DeviceListRequest deviceListRequest) {
        return resourceService.getResourceState(deviceListRequest.getResId());
    }

    @PostMapping("/cameraDeviceList")
    public ResponseEntity<Result> cameraDeviceList(@RequestBody DeviceListRequest deviceListRequest) {
        return resourceService.cameraDeviceList(deviceListRequest.getCampName(), deviceListRequest.getBuildingName());
    }

    /**
     * 控制接口
     *
     * @param controlRequest
     * @return
     * @throws JsonProcessingException
     */
    @PostMapping("/controlResByCom")
    public ResponseEntity<Result> controlResByCom(@RequestBody ControlRequest controlRequest) {
        log.info("控制设备...");
        return resourceService.controlResByCom(controlRequest.getResId(), controlRequest.getCommand());
    }

    @PostMapping("/controlResByPlug")
    public ResponseEntity<Result> controlResByPlug(@RequestBody ControlRequest controlRequest) throws InterruptedException {
        log.info("控制智能插座...");
        return resourceService.controlResByPlug(controlRequest.getResId(), controlRequest.getCommand());
    }

    /**
     * @param resId 设备id
     * @return 当前设备的最终信息
     */
    @GetMapping("/getStaById/{resId}")
    public ResponseEntity<Result> getResourceStateById(@PathVariable Integer resId) {
//        JSONObject jsonObject = new JSONObject();
//        jsonObject.put("id", 21796);
//        jsonObject.put("name", "light");
//        JSONObject property = new JSONObject();
//        property.put("ip", "192.168.15.27");
//        //开启攻击 灯开
//        if ("on".equals(TempConfig.attackStatus)) {
//            if ("on".equals(TempConfig.protectionStatus)) {
//                TempConfig.exceptionFlag = true;
//                property.put("status", TempConfig.light);
//            } else {
//                property.put("status", "on".equals(TempConfig.light) ? "close" : "open");
//            }
//        } else {
//            //关闭攻击 灯关
//            property.put("status", TempConfig.light);
//        }
//        jsonObject.put("property", property);
//        jsonObject.put("resId", 9);
//        jsonObject.put("time", "2023-11-06 15:20:22.0");
//        jsonObject.put("vendor", "YeeLight");
//        return RespResult.successResult(jsonObject);
        return resourceService.getResourceStateById(resId);
    }

    @GetMapping("/getStates")
    public ResponseEntity<Result> getStates() {
        return resourceService.getStates();
    }

    @GetMapping("/getFlowData")
    public ResponseEntity<Result> getFlowData(Integer resId) {
        if (resId == null || resId == 0) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        JSONObject jsonObject = new JSONObject();
        JSONArray array = new JSONArray();
        if (resId == 23) {
            List<Status> statuses = resourceMapper.queryLow15Limit(resId);
            for (Status status : statuses) {
                JSONObject object = new JSONObject();
                JSONObject jsonObject1 = JSONObject.fromObject(status.getProperty());
                object.put("date", status.getTime());
                if (jsonObject1.get("flow") == null) {
                    object.put("flow", 12);
                } else {
                    object.put("flow", jsonObject1.getString("flow"));
                }

                object.put("quali", "合格");
                array.add(object);
            }
            jsonObject.put("flowList", array);
            return RespResult.successResult(jsonObject);
        } else {
            for (int i = 0; i < 15; i++) {
                JSONObject object = new JSONObject();
                object.put("date", "2021-09-29");
                object.put("flow", "0");
                object.put("quali", "合格");
                array.add(object);
            }
            jsonObject.put("flowList", array);
            return RespResult.successResult(jsonObject);
        }
    }

    @GetMapping("/getTemperaAndHumi")
    public ResponseEntity<Result> getTemperaAndHumi(String campName) {
        if (campName == null || "".equals(campName)) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("temperature", 23);
        jsonObject.put("humidity", 67);
        return RespResult.successResult(jsonObject);
    }

    @MessageMapping("/test/{resId}")
    public void webSocketTest(@DestinationVariable String resId) {
        log.info(resId);
        webSocketService.pushResourceState(resId);
    }

    @GetMapping("/getOrderList")
    private ResponseEntity<Result> getOrderList() {
        return resourceService.getOrderList();
    }

    @GetMapping("/getOrderDetail")
    private ResponseEntity<Result> getOrderDetail(String order) {
        return resourceService.getOrderDetail(order);
    }

    @GetMapping("/getCampList")
    private ResponseEntity<Result> getCampList() {
        JSONObject res = new JSONObject();
        JSONArray array = new JSONArray();
        List<String> camps = resourceMapper.queryAllCampDistinct();
        if (camps == null || camps.size() == 0) {
            return RespResult.getResult(StatusCode.QUERYNULL);
        }
        for (int i = 0; i < camps.size(); i++) {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("value", camps.get(i));
            jsonObject.put("label", camps.get(i));
            array.add(jsonObject);
        }
        res.put("campList", array);
        return RespResult.successResult(res);
    }

    @GetMapping("/getButtonList")
    public ResponseEntity<Result> getButtonList(String campName) {
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        if (campName == null) {
            return RespResult.getResult(StatusCode.PARAMS_CHECK_ERROR);
        }
        List<String> buttonList = resourceMapper.queryDistrictByCampname(campName);
        if (buttonList != null && buttonList.size() != 0) {
            JSONObject object = new JSONObject();
            for (String button : buttonList) {
                if ("办公室".equals(button)) {
                    object.put("name", "办公楼");
                } else {
                    object.put("name", button);
                }
                jsonArray.add(object);
            }
            jsonObject.put("btnList", jsonArray);
            return RespResult.successResult(jsonObject);
        }
        return RespResult.getResult(StatusCode.QUERYNULL);
    }

    /**
     * 更新插座状态
     *
     * @return 进行更新操作
     */
    @GetMapping("/updatePlugStatus")
    public int updatePlugStatus() {
        if (!TempConfig.change) {
            if ("on".equals(TempConfig.status)) {
                return 1;
            } else {
                return 0;
            }
        } else {
            if ("on".equals(TempConfig.status)) {
                return 0;
            } else {
                return 1;
            }
        }
    }

    /**
     * 返回当前插座的状态
     *
     * @return 插座状态
     */
    @GetMapping("getPlugStatus")
    public String getPlugStatus() {
        return TempConfig.status;
    }

    /**
     * 更新攻击状态
     */
    @GetMapping("/updateAttackStatus")
    public ResponseEntity<Result> updateAttackStatus(@Param("status") String status) {
        log.info("更新攻击状态：{}",status);
        //开攻击 灯开
        if ("on".equals(status) || "off".equals(status)) {
            TempConfig.attackStatus = status;
        }
        return RespResult.successResult();

    }

    /**
     * 获取攻击状态 李红老师学生接口
     */
     @GetMapping("/getAttackStatus")
    public int getAttackStatus() {
         log.info("获取攻击状态：{}",TempConfig.attackStatus);
        if ("on".equals(TempConfig.attackStatus)) {
            //开启攻击 开灯
            return 1;
        } else if ("off".equals(TempConfig.attackStatus)){
            //关闭攻击 关灯
            return 0;
        }
        throw new RuntimeException();
    }

    /**
     * 获取保护状态 李红老师学生的接口
     */
     @GetMapping("/getProtectionStatus")
    public int getProtectionStatus() {
         log.info("获取保护状态：{}",TempConfig.protectionStatus);
        if ("on".equals(TempConfig.protectionStatus)) {
            //开启保护
            return 1;
        } else {
            //关闭保护
            return 0;
        }
    }

    /**
     * 更新保护状态
     */
    @GetMapping("/updateProtectionStatus")
    public ResponseEntity<Result> updateProtectionStatus(@Param("status") String status) {
        log.info("更新保护状态：{}",status);
        if ("on".equals(status) || "off".equals(status)) {
            TempConfig.protectionStatus = status;
        }
        return RespResult.successResult();
    }


    /**
     * 是否发生异常
     */
    @GetMapping("/getExceptionStatus")
    public int getExceptionStatus(){
        log.info("获取异常状态：{}",TempConfig.exceptionFlag);
        if (TempConfig.exceptionFlag) {
            TempConfig.exceptionFlag = false;
            if ("on".equals(TempConfig.attackStatus)) {
                TempConfig.attackStatus = "off";
            } else if ("off".equals(TempConfig.attackStatus)){
                TempConfig.attackStatus = "on";
            }
            return 1;
        } else {
            return 0;
        }
    }

    private final ReentrantLock exceptionLock = new ReentrantLock();

    /**
     * 更新异常状态 李红老师学生的接口
     */
    @GetMapping("/updateExceptionStatus")
    public void updateExceptionStatus(@Param("status") int status) {
        log.info("更新异常状态：{}",status);
        exceptionLock.lock();
        try {
            //0表示未发生异常状况
            if ("on".equals(TempConfig.protectionStatus)) {
                if (0 == status) {
                    //默认false 状态保证异常状态不会被直接冲刷掉
                    //好像没用
                    if (!TempConfig.exceptionFlag) {
                        TempConfig.exceptionFlag = false;
                        //修复attackStatus
                    }
                } else if (1 == status) {
                    //开启异常状态 更新异常状态 并且在1秒后重置攻击状态
                    TempConfig.exceptionFlag = true;
                    //Thread.sleep(1000);
                    //更新attackStatus
                    //if (!TempConfig.exceptionFlag) {
                    //    TempConfig.exceptionFlag = true;
                    //    if ("on".equals(TempConfig.attackStatus)) {
                    //        TempConfig.attackStatus = "off";
                    //    } else {
                    //        TempConfig.attackStatus = "on";
                    //    }
                    //}
                }
            }
        } finally {
            exceptionLock.unlock();
        }
        //更新异常状态
    }
}
