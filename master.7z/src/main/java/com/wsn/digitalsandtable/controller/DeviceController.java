package com.wsn.digitalsandtable.controller;

import com.github.pagehelper.PageInfo;
import com.wsn.digitalsandtable.common.RespResult;
import com.wsn.digitalsandtable.common.Result;
import com.wsn.digitalsandtable.entity.param.DeviceMoveParam;
import com.wsn.digitalsandtable.entity.param.DevicePageParam;
import com.wsn.digitalsandtable.entity.vo.DeviceVo;
import com.wsn.digitalsandtable.service.DeviceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author liwu
 * @date 2022.1.11 18:48
 */
@RestController
@RequestMapping("/device")
@CrossOrigin
@Slf4j
public class DeviceController {
    @Autowired
    private DeviceService deviceService;

    @PostMapping("/list")
    public ResponseEntity<Result> getPageDeviceList(@RequestBody DevicePageParam param) {
        PageInfo<DeviceVo> page = deviceService.getDevicePageList(param);
        return RespResult.successResult(page);
    }

    @PostMapping("/reset-location")
    public ResponseEntity<Result> resetDeviceLocation() {
        return deviceService.resetDeviceLocation();
    }

    @PostMapping("/move-campsite")
    public ResponseEntity<Result> moveCampsite(@RequestBody DeviceMoveParam param){
        return deviceService.moveCampsite(param);
    }
}
