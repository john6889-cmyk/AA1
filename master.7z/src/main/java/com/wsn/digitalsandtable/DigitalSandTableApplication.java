package com.wsn.digitalsandtable;

//import com.wsn.digitalsandtable.util.WebsocketServer;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.ConfigurableBootstrapContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@MapperScan(basePackages = "com.wsn.digitalsandtable.mapper")
public class DigitalSandTableApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext = SpringApplication.run(DigitalSandTableApplication.class, args);
		//WebsocketServer.setContext(applicationContext);
	}

}
