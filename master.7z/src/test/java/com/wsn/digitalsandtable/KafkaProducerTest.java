package com.wsn.digitalsandtable;

import com.wsn.digitalsandtable.mapper.ResourceMapper;
import net.sf.json.JSONObject;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.common.protocol.types.Field;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;

/**
 * @Author ZhaoMingHui
 * @Date 2021/9/18 15:44
 * @Version 1.0
 */

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class KafkaProducerTest {

    @Autowired
    private KafkaTemplate<String,Object> kafkaTemplate;

    @Value("${spring.kafka.provider.topic}")
    private String topic;

    @Autowired
    private ResourceMapper resourceMapper;

    @Test
    void producerTest(){
        //KafkaProducer<String,String> producer = new KafkaProducer<String, String>();
        JSONObject sendObject = new JSONObject();
        sendObject.put("cmd","control");
        sendObject.put("model","yeelight_led_light");
        sendObject.put("ip","192.168.31.100");
        SecureRandom random = new SecureRandom();

        while (true){
            int i = random.nextInt(2);
            if (i == 0){
                sendObject.put("power","off");
            }else {
                sendObject.put("power","on");
            }

            kafkaTemplate.send(topic,sendObject.toString());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Test
    void jsonTest(){
        String tar = "{\"age\":18,\"sex\":\"男\"}";
        JSONObject jsonObject = JSONObject.fromObject(tar);
        //System.out.println(jsonObject.getString("name"));
        System.out.println(jsonObject.get("name"));
        System.out.println(jsonObject.get("sex"));
        System.out.println(jsonObject.get("age").equals(18));
        System.out.println(Integer.parseInt(jsonObject.get("age").toString()) == 18);
    }


    @Test
    void importLogisData() throws IOException {
        String tagFilePath = "C:\\Users\\Administrator\\Desktop\\detectData.txt";

        BufferedReader reader = new BufferedReader(new FileReader(tagFilePath));
        String line = reader.readLine();

        do {
            line = line.replace("\\r\\n","");
            JSONObject jsonObject = JSONObject.fromObject(line);
            System.out.println(jsonObject.getString("qRCode"));
            Integer id = Integer.parseInt(jsonObject.getString("id"));
            String deliveryTime = jsonObject.getString("deliveryTime");
            String orderStatus = jsonObject.getString("orderStatus");
            String senderAddress = jsonObject.getString("senderAddress");
            String senderName = jsonObject.getString("senderName");
            String senderPhone = jsonObject.getString("senderPhone");
            String userAddress = jsonObject.getString("userAddress");
            String userId = jsonObject.getString("userId");
            String userName = jsonObject.getString("userName");
            String userPhone = jsonObject.getString("userPhone");
            String qrCode = jsonObject.getString("qRCode");

            resourceMapper.insertLogisOrderData(id,deliveryTime,orderStatus,senderAddress,senderName,senderPhone,userAddress,userId,userName,userPhone,qrCode);
        }while ((line = reader.readLine()) != null);
    }

}
